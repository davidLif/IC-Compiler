
public interface ICommand {
	/* execute code command */
	public void execute();
}
